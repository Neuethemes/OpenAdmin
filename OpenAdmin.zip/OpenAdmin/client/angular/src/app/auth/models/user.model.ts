export class User {
  public _id: number;
  public email: string;
  public password: string;
  public firstName: string;
  public lastName: string;
  public avatar: string;
  public token: string;
}
