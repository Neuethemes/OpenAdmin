import { Component } from '@angular/core';

@Component({
  templateUrl: './auth.component.html',
})

export class AuthComponent {

}
