export class LayoutService {
  isSidebarLeftCollapsed: boolean = false;
  isSidebarRightCollapsed: boolean = true;
}
