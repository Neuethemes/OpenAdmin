import { Component } from '@angular/core';

@Component({
  templateUrl: './icons.component.html'
})
export class PageIconsComponent {
}
