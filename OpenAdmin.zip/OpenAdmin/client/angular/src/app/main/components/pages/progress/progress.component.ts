import { Component } from '@angular/core';

@Component({
  templateUrl: './progress.component.html'
})
export class PageProgressComponent {
}
