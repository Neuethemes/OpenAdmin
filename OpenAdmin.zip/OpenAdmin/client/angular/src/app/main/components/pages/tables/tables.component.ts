import { Component } from '@angular/core';

@Component({
  templateUrl: './tables.component.html'
})
export class PageTablesComponent {
}
