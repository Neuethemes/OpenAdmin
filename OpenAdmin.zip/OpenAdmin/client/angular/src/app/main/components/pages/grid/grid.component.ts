import { Component } from '@angular/core';

@Component({
  templateUrl: './grid.component.html'
})
export class PageGridComponent {
}
