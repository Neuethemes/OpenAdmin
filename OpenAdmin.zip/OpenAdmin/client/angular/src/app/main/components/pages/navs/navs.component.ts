import { Component } from '@angular/core';

@Component({
  templateUrl: './navs.component.html'
})
export class PageNavsComponent {
}
